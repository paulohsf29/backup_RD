export interface Cards {
    cardTitle: string;
    cardText: string;
    cardTitle2: string;
    cardTitle3: string;
}
