import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-fechamento-caixa',
  templateUrl: './modal-fechamento-caixa.component.html',
  styleUrls: ['./modal-fechamento-caixa.component.css']
})
export class ModalFechamentoCaixaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
