import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-abertura-caixa',
  templateUrl: './modal-abertura-caixa.component.html',
  styleUrls: ['./modal-abertura-caixa.component.css']
})
export class ModalAberturaCaixaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
