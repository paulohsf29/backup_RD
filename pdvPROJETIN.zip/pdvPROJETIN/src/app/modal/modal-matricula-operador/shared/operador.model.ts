export interface Operador {
  nmMatricula: string,
  nmNome: string
}

export interface ResponseOperador {
  operador: Operador[];
}
